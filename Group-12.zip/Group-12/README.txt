
Kidney Disease Classification

This project focuses on building a classification model to predict kidney disease using various machine learning algorithms. The dataset used is kidney_disease.csv, which contains multiple features related to medical and physical conditions.

Project Structure

- Data Loading and Preprocessing: The dataset is loaded, and columns are renamed for better readability. Missing values are handled using various imputation techniques. Typos and inconsistent data entries are also corrected.
- Feature Engineering: Categorical columns are encoded, and numeric columns are standardized.
- Dimensionality Reduction: PCA is applied to reduce the number of features.
- Model Training and Evaluation: Multiple machine learning models are trained, evaluated, and compared.

Dependencies

Ensure you have the following Python libraries installed:

- pandas
- numpy
- scikit-learn
- matplotlib
- seaborn
- plotly

Install the necessary packages using:

pip install pandas numpy scikit-learn matplotlib seaborn plotly

Data Source

The dataset can be downloaded from Kaggle:
[Chronic Kidney Disease Dataset](https://www.kaggle.com/datasets/mansoordaku/ckdisease)

Steps

1. Data Loading and Preprocessing:
   df = pd.read_csv("kidney_disease.csv")
   # Renaming columns, converting data types, handling incorrect values, and imputing missing values

2. Feature Engineering:
   # Encode categorical variables and standardize numerical features

3. PCA for Dimensionality Reduction:
   pca = PCA(n_components=10)
   X_pca = pca.fit_transform(X_scaled)

4. Train-Test Split:
   X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=0.2, random_state=42)

5. Model Training and Evaluation:
   logreg = LogisticRegression(random_state=42)
   logreg.fit(X_train, y_train)
   # Repeat for other models

6. Confusion Matrix Visualization:
   def plot_confusion_matrix(y_true, y_pred, title):
       cm = confusion_matrix(y_true, y_pred)
       sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
       plt.title(title)
       plt.ylabel('Actual')
       plt.xlabel('Predicted')
       plt.show()

   plot_confusion_matrix(y_test, y_pred_log, "Confusion Matrix - Logistic Regression")

Model Performance

- Logistic Regression:
  - Training Accuracy: 0.99375
  - Test Accuracy: 0.975
  - Classification Report: 

- Decision Tree Classifier:
  - Training Accuracy: 1.0
  - Test Accuracy: 0.9625
  - Classification Report: ...

- Random Forest Classifier:
  - Training Accuracy: 1.0
  - Test Accuracy: 0.975 
  - Classification Report: ...

- K-Nearest Neighbors:
  - Training Accuracy: 0.984375
  - Test Accuracy: 0.9875 
  - Classification Report: ...

Confusion Matrices

Confusion matrices are plotted for each model to visualize the performance.

Comparison Plot

A bar plot is created using Plotly to compare the accuracy of different models.

px.bar(data_frame=models, x='Score', y='Model', color='Score', template='plotly_dark', title='Models Comparison')

Conclusion

This project demonstrates the process of building, evaluating, and comparing different machine learning models for kidney disease classification. The performance of each model is visualized using confusion matrices and comparison plots.
